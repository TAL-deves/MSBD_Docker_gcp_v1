let coursesData = [
    { "courseID":"C001",
      "lessons":[{
        title: "C001 course lesson 1",
        link: "https://media.w3.org/2010/05/sintel/trailer_hd.mp4",
      },{
        title: "C001 course lesson 2",
        link: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_1MB.mp4",
      },{
        title: "C001 course lesson 3",
        link: "https://media.w3.org/2010/05/sintel/trailer_hd.mp4",
      },{
        title: "C001 course lesson 4",
        link: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_1MB.mp4",
      },{
        title: "C001 course lesson 5",
        link: "https://media.w3.org/2010/05/sintel/trailer_hd.mp4",
      }
    ]
  },
    { "courseID":"C002",
      "lessons":[{
        title: "C002 course lesson 1",
        link: "https://media.w3.org/2010/05/sintel/trailer_hd.mp4",
      },{
        title: "C002 course lesson 2",
        link: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_1MB.mp4",
      },{
        title: "C002 course lesson 3",
        link: "https://media.w3.org/2010/05/sintel/trailer_hd.mp4",
      },{
        title: "C002 course lesson 4",
        link: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_1MB.mp4",
      },{
        title: "C002 course lesson 5",
        link: "https://media.w3.org/2010/05/sintel/trailer_hd.mp4",
      },
    ]
  }
  ];


module.exports = {
  coursesData: coursesData,
};
