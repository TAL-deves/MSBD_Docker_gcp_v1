
export default class ResponseDetails {
    constructor(data, result) {
        this.data = data;
        this.result = result;
      }
}

// export default {ResponseDetails};
